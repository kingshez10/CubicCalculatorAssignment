﻿using CalculatorUtilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorTest
{
    public class SimpleCalculator : ISimpleCalculator
    {

        IDiagnostic diagnostic;
        IDiagnostic Diagnostic
        {
            get
            {
                if (diagnostic == null)
                    diagnostic = ResolveDependency.GetInstanceGeneral<IDiagnostic>();
                return diagnostic;
            }
        }

        public SimpleCalculator()
        {

        }

        public SimpleCalculator(IDiagnostic _diagnostic)
        {
            diagnostic = _diagnostic;
        }





        public ResultDTO Add(int start, int amount)
        {
            ResultDTO resultDTO = new ResultDTO();
            resultDTO.Result = start + amount;
            resultDTO.Report = Diagnostic.Diagnose(start,amount, resultDTO.Result, Constants.Adding);
            return resultDTO;
        }

        public ResultDTO Subtract(int start, int amount)
        {
            ResultDTO resultDTO = new ResultDTO();
            resultDTO.Result =  start - amount;
            resultDTO.Report = Diagnostic.Diagnose(start, amount, resultDTO.Result, Constants.Subtracting);
            return resultDTO;
        }

        public ResultDTO Divide(int start, int by)
        {
            ResultDTO resultDTO = new ResultDTO();
            resultDTO.Result = start / by;
            resultDTO.Report = Diagnostic.Diagnose(start, by, resultDTO.Result, Constants.Dividing);
            return resultDTO;
        }

        public ResultDTO Multiply(int start, int by)
        {
            ResultDTO resultDTO = new ResultDTO();
            resultDTO.Result = start * by;
            resultDTO.Report = Diagnostic.Diagnose(start, by, resultDTO.Result, Constants.Multiplying);
            return resultDTO;
        }
    }
}
