﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorTest
{
    public interface ISimpleCalculator
    {       
        ResultDTO Add(int start, int amount);
        ResultDTO Subtract(int start, int amount);
        ResultDTO Multiply(int start, int by);
        ResultDTO Divide(int start, int by);
    }
}
