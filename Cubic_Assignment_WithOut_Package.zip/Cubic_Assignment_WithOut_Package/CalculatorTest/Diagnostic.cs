﻿using CalculatorDataAccess;
using CalculatorUtilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorTest
{
    public class Diagnostic : IDiagnostic, IDiagnosticDummy
    {
        IDataAccess dataAccess = null;
        IDataAccess DataAccess
        {
            get
            {
                if (dataAccess == null)
                    dataAccess = ResolveDependency.GetInstanceGeneral<IDataAccess>();
              return dataAccess;
            }
        }


        public string Diagnose(int number1, int number2, int result, string operation)
        {
            string diagnosticMessage= "By " + operation + " number1 = " + number1 + " by number2 = " + number2 + " result will be = " + result;
            DataAccess.SaveDiagnostic(diagnosticMessage);
            return diagnosticMessage;
        }
    }
}
