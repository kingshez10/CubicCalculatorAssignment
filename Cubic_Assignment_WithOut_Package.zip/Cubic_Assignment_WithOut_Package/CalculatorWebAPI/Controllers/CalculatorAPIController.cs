﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CalculatorTest;
using CalculatorUtilities;

namespace CalculatorWebAPI.Controllers
{
    public class CalculatorAPIController : ApiController
    {

        ISimpleCalculator simpleCalculator;
        ISimpleCalculator SimpleCalculator
        {
            get
            {
                if (simpleCalculator == null)
                    simpleCalculator = ResolveDependency.GetInstanceGeneral<ISimpleCalculator>(); 

                return simpleCalculator;
            }
        }

        [Route("api/Calculator/Add/{start}/{amount}")]
        [HttpGet]
        public ResultDTO GetAddResult(int start, int amount)
        {
            return SimpleCalculator.Add(start, amount);
        }

        [Route("api/Calculator/Subtract/{start}/{amount}")]
        [HttpGet]
        public ResultDTO GetSubtractResult(int start, int amount)
        {
            return SimpleCalculator.Subtract(start, amount);
        }

        [Route("api/Calculator/Divide/{start}/{by}")]
        [HttpGet]
        public ResultDTO GetDivideResult(int start, int by)
        {
            return SimpleCalculator.Divide(start, by);
        }

        [Route("api/Calculator/Multiply/{start}/{by}")]
        [HttpGet]
        public ResultDTO GetMultiplyResult(int start, int by)
        {
            return SimpleCalculator.Multiply(start, by);
        }
    }
}
