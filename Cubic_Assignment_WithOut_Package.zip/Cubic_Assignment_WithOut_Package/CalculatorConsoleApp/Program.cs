﻿using CalculatorTest;
using CalculatorUtilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter number1");
            int number1 = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("Please enter number2");
            int number2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please enter the operation from one of these +,-,*,/ to be performed on two numbers");
            string operation = Console.ReadLine();
            PerformOperation(number1, number2, operation);
        }

        private static void PerformOperation(int number1,int number2, string operation)
        {
            HttpResponseMessage response = null;
            string baseURL = System.Configuration.ConfigurationSettings.AppSettings["BaseURL"].ToString();
            switch (operation)
            {
                case Constants.Add:
                    response = SendHttpRequest(baseURL, "api/Calculator/Add/"+number1+"/"+number2);
                   break;
                case Constants.Subtract:
                    response = SendHttpRequest(baseURL, "api/Calculator/Subtract/" + number1 + "/" + number2);
                    break;
                case Constants.Multiply:
                    response = SendHttpRequest(baseURL, "api/Calculator/Multiply/" + number1 + "/" + number2);
                    break;
                case Constants.Divide:
                    response = SendHttpRequest(baseURL, "api/Calculator/Divide/" + number1 + "/" + number2);
                    break;
                default:
                    Console.WriteLine("Invalied Operation");
                    break;
            }
           
            DisplayReport(response);
        }


        private static HttpResponseMessage SendHttpRequest(string baseURL,string apiURL)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseURL);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //GET Method  
                HttpResponseMessage response = client.GetAsync(apiURL).Result;
                return response;
            }
        }

        private static void DisplayReport(HttpResponseMessage response)
        {
            if (response != null && response.IsSuccessStatusCode)
            {
                ResultDTO resultDTO = JsonConvert.DeserializeObject<ResultDTO>(response.Content.ReadAsStringAsync().Result);
                Console.WriteLine("\n\n" + resultDTO.Report);
            }
            else
            {
                Console.WriteLine("Internal server Error");
            }

            Console.Read();
        }
    }
}
