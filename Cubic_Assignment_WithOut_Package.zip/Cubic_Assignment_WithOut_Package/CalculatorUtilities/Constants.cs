﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorUtilities
{
    public static class Constants
    {
        public const string Adding = "Adding";
        public const string Subtracting = "Subtracting";
        public const string Multiplying = "Multiplying";
        public const string Dividing = "Dividing";
        public const string Add = "+";
        public const string Subtract = "-";
        public const string Divide = "/";
        public const string Multiply = "*";
    }
}
