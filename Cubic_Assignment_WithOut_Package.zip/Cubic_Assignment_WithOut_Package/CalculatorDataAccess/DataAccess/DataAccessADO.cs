﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorDataAccess
{
    public class DataAccessADO : IDataAccess
    {
        public void SaveDiagnostic(string diagnosticMessage)
        {
            // Create the connection.
            using (SqlConnection connection = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["ADOConn"].ToString()))
            {
                // Create a SqlCommand, and identify it as a stored procedure.
                using (SqlCommand sqlCommand = new SqlCommand("usp_SaveDiagnosticMessage", connection))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;

                    // Add input parameter for the stored procedure and specify what to use as its value.
                    sqlCommand.Parameters.Add(new SqlParameter("@DiagnoisticMessage", SqlDbType.VarChar,10000));
                    sqlCommand.Parameters["@DiagnoisticMessage"].Value = diagnosticMessage;

                    try
                    {
                        connection.Open();

                        // Run the stored procedure.
                        sqlCommand.ExecuteNonQuery();
                    }
                    catch(Exception exp)
                    {
                        throw exp;
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
        }
    }
}
