﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorDataAccess
{
    public class DataAccessEF : IDataAccess
    {
        public void SaveDiagnostic(string diagnosticMessage)
        {
            using (UnitOfWork unitOfWork = new UnitOfWork(new CalculatorDianosticEntities()))
            {
                var dbContextTransaction = unitOfWork.Context.Database.BeginTransaction();
                Diagnostic diagnosticEntity = new Diagnostic();
                diagnosticEntity.Message = diagnosticMessage;
                diagnosticEntity.CreatedOn = DateTime.UtcNow;
                unitOfWork.Context.Diagnostics.Add(diagnosticEntity);
                try
                {
                    unitOfWork.Save();
                }
                catch (DbEntityValidationException e)
                {
                    dbContextTransaction.Rollback();
                    throw e;
                }
                catch (DbUpdateException e)
                {
                    dbContextTransaction.Rollback();
                    throw e;
                }
                dbContextTransaction.Commit();
            }
        }
    }
}
