﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorDataAccess
{

    public abstract class Service
    {
        protected UnitOfWork _unitOfWork;

        public Service(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
    }

}
