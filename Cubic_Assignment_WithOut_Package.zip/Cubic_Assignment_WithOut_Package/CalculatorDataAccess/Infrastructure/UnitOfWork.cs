﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorDataAccess
{
    public class UnitOfWork : IDisposable
    {
        #region Data Members
        private readonly CalculatorDianosticEntities _context;
        private readonly Guid _instanceId;
        private bool _disposed;
        public CalculatorDianosticEntities Context { get; private set; }
        #endregion 

        #region Methods
        public UnitOfWork(CalculatorDianosticEntities context)
        {
            Context = context;
            _instanceId = Guid.NewGuid();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed && disposing)
            {
                Context.Dispose();
            }
            _disposed = true;
        }

        public Guid InstanceId
        {
            get { return _instanceId; }
        }

        public void Save()
        {
            Context.SaveChanges();
        }

        public Task<int> SaveAsync()
        {
            return Context.SaveChangesAsync();
        }
        #endregion 
    }
}
    