﻿using System;
using CalculatorTest;
using CalculatorUtilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace UnitTestProject1
{
    [TestClass]
    public class CalculatorTest
    {
       
        [TestMethod]
        public void Add_Test()
        {
            //arrange            
            int start = 5;
            int amount = 10;
            int expectedResult = start + amount;
            string expectedDiagnosticMessage = "By " + Constants.Adding + " number1 = " + start + " by number2 = " + amount + " result will be = " + expectedResult;
            ResultDTO expectedOutPut = new ResultDTO();
            expectedOutPut.Result = expectedResult;
            expectedOutPut.Report = expectedDiagnosticMessage;
            //Mocking
            Mock<IDiagnostic> mockDiagnostic = new Mock<IDiagnostic>();
            mockDiagnostic.Setup(m => m.Diagnose(start,amount,expectedResult,Constants.Adding)).Returns(expectedDiagnosticMessage);
            //Object intiation  for unit test
            ISimpleCalculator simpleCalculator = new SimpleCalculator(mockDiagnostic.Object);
            //act
            ResultDTO actualOutPut = simpleCalculator.Add(start, amount);
            //assert
            Assert.AreEqual(expectedOutPut.Result, actualOutPut.Result);
            Assert.AreEqual(expectedOutPut.Report, actualOutPut.Report);
        }

       

        [TestMethod]
        public void Subtract_Test()
        {
            //arrange
            int start = 10;
            int amount = 5;
            int expectedResult = start - amount;
            string expectedDiagnosticMessage = "By " + Constants.Subtracting + " number1 = " + start + " by number2 = " + amount + " result will be = " + expectedResult;
            ResultDTO expectedOutPut = new ResultDTO();
            expectedOutPut.Result = expectedResult;
            expectedOutPut.Report = expectedDiagnosticMessage;
            //Mocking
            Mock<IDiagnostic> mockDiagnostic = new Mock<IDiagnostic>();
            mockDiagnostic.Setup(m => m.Diagnose(start, amount, expectedResult, Constants.Subtracting)).Returns(expectedDiagnosticMessage);
            //Object intiation  for unit test
            ISimpleCalculator simpleCalculator = new SimpleCalculator(mockDiagnostic.Object);
            //act
            ResultDTO actualOutPut = simpleCalculator.Subtract(start, amount);
            //assert
            Assert.AreEqual(expectedOutPut.Result, actualOutPut.Result);
            Assert.AreEqual(expectedOutPut.Report, actualOutPut.Report);
        }


        [TestMethod]
        public void Divide_Test()
        {
            //arrange
            int start = 10;
            int by = 5;
            int expectedResult = start / by;
            string expectedDiagnosticMessage = "By " + Constants.Dividing + " number1 = " + start + " by number2 = " + by + " result will be = " + expectedResult;
            ResultDTO expectedOutPut = new ResultDTO();
            expectedOutPut.Result = expectedResult;
            expectedOutPut.Report = expectedDiagnosticMessage;
            //Mocking
            Mock<IDiagnostic> mockDiagnostic = new Mock<IDiagnostic>();
            mockDiagnostic.Setup(m => m.Diagnose(start, by, expectedResult, Constants.Dividing)).Returns(expectedDiagnosticMessage);
            //Object intiation  for unit test
            ISimpleCalculator simpleCalculator = new SimpleCalculator(mockDiagnostic.Object);
            //act
            ResultDTO actualOutPut = simpleCalculator.Divide(start, by);
            //assert
            Assert.AreEqual(expectedOutPut.Result, actualOutPut.Result);
            Assert.AreEqual(expectedOutPut.Report, actualOutPut.Report);
        }



        [TestMethod]
        public void Multiply_Test()
        {
            //arrange
            int start = 5;
            int by = 2;
            int expectedResult = start * by;
            string expectedDiagnosticMessage = "By " + Constants.Multiplying + " number1 = " + start + " by number2 = " + by + " result will be = " + expectedResult;
            ResultDTO expectedOutPut = new ResultDTO();
            expectedOutPut.Result = expectedResult;
            expectedOutPut.Report = expectedDiagnosticMessage;
            //Mocking
            Mock<IDiagnostic> mockDiagnostic = new Mock<IDiagnostic>();
            mockDiagnostic.Setup(m => m.Diagnose(start, by, expectedResult, Constants.Multiplying)).Returns(expectedDiagnosticMessage);
            //Object intiation  for unit test
            ISimpleCalculator simpleCalculator = new SimpleCalculator(mockDiagnostic.Object);
            //act
            ResultDTO actualOutPut = simpleCalculator.Multiply(start, by);
            //assert
            Assert.AreEqual(expectedOutPut.Result, actualOutPut.Result);
            Assert.AreEqual(expectedOutPut.Report, actualOutPut.Report);
        }
    }
}
